﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class Add_Donor_UI : Form
    {
        public Add_Donor_UI()
        {
            InitializeComponent();
        }
        void populateData()
        {
            DonorOperations op = new DonorOperations();
            DataSet ds = op.ShowDonors();
            DonordataGridView.DataSource = ds.Tables[0];
        }

        private void Add_Donor_UI_Load(object sender, EventArgs e)
        {
            populateData();
            DonordataGridView.Columns["Did"].HeaderText = "id";
            DonordataGridView.Columns["FirstName"].HeaderText = "FirstName";
            DonordataGridView.Columns["LastName"].HeaderText = "Last Name";
            DonordataGridView.Columns["ContactNo"].HeaderText = "ContactNO";
            DonordataGridView.Columns["BloodGroup"].HeaderText = "Blood GROUP";
            DonordataGridView.Columns["City"].HeaderText = "City";
            DonordataGridView.Columns["Area"].HeaderText = "Area";

        }

        

        private void EDIT_Click(object sender, EventArgs e)
        {
            Address AD = new Address();
            Donor D = new Donor(AD);
            DonorOperations op = new DonorOperations();
            string s = FirstName.Text;
            if (key == 0)
            {
                MessageBox.Show("Select the Donor");
            }
            else if (String.IsNullOrEmpty(FirstName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (char.IsDigit(s[0]))
            {
                MessageBox.Show("First Letter can not be a number!");
            }
            else if (String.IsNullOrEmpty(LastName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(PhoneNo.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(BloodGroup.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Area.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(City.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }

            else
            {

                try
                {
                    D.FirstName = FirstName.Text;
                    D.LastName = LastName.Text;
                    D.Phone = PhoneNo.Text;
                    D.BloodGroup = BloodGroup.SelectedItem.ToString();
                    D.area = Area.Text;
                    D.city = City.Text;
                    op.UpdateDonors(key, D);
                    MessageBox.Show("Donor info Succesfully Updated");
                    populateData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
        int key = 0;
        private void DonordataGridViewClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.DonordataGridView.Rows[e.RowIndex];
                FirstName.Text = row.Cells["FirstName"].Value.ToString();
                LastName.Text = row.Cells["LastName"].Value.ToString();
                PhoneNo.Text = row.Cells["PhoneNo"].Value.ToString();
                BloodGroup.Text = row.Cells["BloodGroup"].Value.ToString();
                City.Text = row.Cells["City"].Value.ToString();
                Area.Text = row.Cells["Area"].Value.ToString();
            }


            if (FirstName.Text == "")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(DonordataGridView.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void ADD_Click(object sender, EventArgs e)
        {
            Donor D = new Donor();
            DonorOperations OP = new DonorOperations();
            string s = FirstName.Text;

            if (String.IsNullOrEmpty(FirstName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }

            else if (String.IsNullOrEmpty(LastName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (char.IsDigit(s[0]))
            {
                MessageBox.Show("First Letter can not be a number!");
            }
            else if (String.IsNullOrEmpty(BloodGroup.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(City.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Area.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            
            else
            {

                try
                {
                    D.FirstName = FirstName.Text;
                    D.LastName = LastName.Text;
                    D.Dphone = PhoneNo.Text;
                    D.DBGrp = BloodGroup.Text;
                    D.Dcity = City.Text;
                    D.Darea = Area.Text;
                 
                    MessageBox.Show("Doctor info Succesfully Added!");
                    OP.InsertDonor(D);
                    populateData();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

        }

        private void REMOVE_Click(object sender, EventArgs e)
        {
            DonorOperations op = new DonorOperations();
            if (key == 0)
            {
                MessageBox.Show("Select the Donor");
            }
            else if (FirstName.Text == "" || LastName.Text == "" || PhoneNo.Text == "" || BloodGroup.SelectedItem == null || Area.Text == "" || City.Text == "")
            {
                MessageBox.Show("Select the Donor");
            }
            else
            {
                try
                {

                    op.DeleteDonors(key);
                    MessageBox.Show("Donor Succesfully Deleted");
                    FirstName.Text = "";
                    LastName.Text = "";
                    PhoneNo.Text = "";
                    BloodGroup.SelectedItem = null;
                    Area.Text = "";
                    City.Text = "";
                    populateData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void DonordataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.DonordataGridView.Rows[e.RowIndex];
                FirstName.Text = row.Cells["FirstName"].Value.ToString();
                LastName.Text = row.Cells["LastName"].Value.ToString();
                PhoneNo.Text = row.Cells["PhoneNo"].Value.ToString();
                BloodGroup.Text = row.Cells["BloodGroup"].Value.ToString();
                City.Text = row.Cells["City"].Value.ToString();
                Area.Text = row.Cells["Area"].Value.ToString();
            }


            if (FirstName.Text == "")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(DonordataGridView.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            new AddDoctor_UI().Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new DashBoard().Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            new AdminProfile().Show();
            this.Hide();
        }
    }
}
