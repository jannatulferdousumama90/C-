﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class AddDoctor_UI : Form
    {
        public AddDoctor_UI()
        {
            InitializeComponent();
        }

        private void AddDoctor_UI_Load(object sender, EventArgs e)
        {
            
                populateData();
            dataGridView1.Columns["Drid"].HeaderText = "ID";
            dataGridView1.Columns["FirstName"].HeaderText = "First Name";
            dataGridView1.Columns["LastName"].HeaderText = "Last Name";
            dataGridView1.Columns["Degree"].HeaderText = "Degree";
            dataGridView1.Columns["Department"].HeaderText = "Department";
            dataGridView1.Columns["Chamber"].HeaderText = "Chamber";
            dataGridView1.Columns["VisitingHours"].HeaderText = "Visiting Hours";
            dataGridView1.Columns["VisitingDays"].HeaderText = "Visiting Days";
            dataGridView1.Columns["ForAppointment"].HeaderText = "For Appointmnent";

        }

        private void Addtxt_Click(object sender, EventArgs e)
        {
            Doctor Dr = new Doctor();
            DoctorOperations OP = new DoctorOperations();
            string s = FirstName.Text;

            if (String.IsNullOrEmpty(FirstName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }

            else if (String.IsNullOrEmpty(LastName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (char.IsDigit(s[0]))
            {
                MessageBox.Show("First Letter can not be a number!");
            }
            else if (String.IsNullOrEmpty(VisitingDays.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(VisitingHours.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Chamber.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Degree.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Department.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(ForAppointment.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else
            {

                try
                {
                    Dr.FirstName = FirstName.Text;
                    Dr.LastName = LastName.Text;
                    Dr.visiting_days = VisitingDays.Text;
                    Dr.Visitng_Hours = VisitingHours.Text;
                    Dr.Chammber = Chamber.Text;
                    Dr.Degree = Degree.Text;
                    Dr.Department = Department.Text;
                    Dr.Appoinment_CallNo = ForAppointment.Text;
                    MessageBox.Show("Doctor info Succesfully Added!");
                    OP.InsertDoctor(Dr);
                    populateData();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

    
        void populateData()
        {
            DoctorOperations OP = new DoctorOperations();
            DataSet ds = OP.ShowDoctors();
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void Edittxt_Click(object sender, EventArgs e)
        {
            Doctor Dr = new Doctor();
            DoctorOperations op = new DoctorOperations();
            string s = FirstName.Text;
            if (key == 0)
            {
                MessageBox.Show("Select the DOCTOR");
            }

            else if (String.IsNullOrEmpty(FirstName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (char.IsDigit(s[0]))
            {
                MessageBox.Show("First Letter can not be a number!");
            }
            else if (String.IsNullOrEmpty(LastName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(VisitingDays.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(VisitingHours.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Chamber.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Degree.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Department.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(ForAppointment.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }

            else
            {

                try
                {
                    Dr.FirstName = FirstName.Text;
                    Dr.LastName = LastName.Text;
                    Dr.visiting_days = VisitingDays.Text;
                    Dr.Visitng_Hours = VisitingHours.Text;
                    Dr.Chammber = Chamber.Text;
                    Dr.Degree = Degree.Text;
                    Dr.Department = Department.Text;
                    Dr.Appoinment_CallNo = ForAppointment.Text;
                    op.UpdateDoctors(key, Dr);
                    MessageBox.Show("Doctor info Succesfully Updated");
                    populateData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        int key = 0;

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

                FirstName.Text = row.Cells["FirstName"].Value.ToString();
                LastName.Text = row.Cells["LastName"].Value.ToString();
                Degree.Text = row.Cells["Degree"].Value.ToString();
                Department.Text = row.Cells["Department"].Value.ToString();
                Chamber.Text = row.Cells["Chamber"].Value.ToString();
                VisitingHours.Text = row.Cells["VisitingHours"].Value.ToString();
                VisitingDays.Text = row.Cells["VisitingDays"].Value.ToString();
                ForAppointment.Text = row.Cells[" ForAppointment"].Value.ToString();
            }

            if (FirstName.Text == "")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void Removetxt_Click(object sender, EventArgs e)
        {
            DoctorOperations op = new DoctorOperations();
            if (key == 0)
            {
                MessageBox.Show("Select the Doctor");
            }
            else if (FirstName.Text == "" || LastName.Text == "" || VisitingDays.Text == "" || VisitingHours.Text == "" || Chamber.Text == "" || Degree.Text == "" || Department.Text == "" || ForAppointment.Text == "")
            {
                MessageBox.Show("Select the Doctor");
            }

            else
            {


                try
                {

                    op.DeleteDoctors(key);
                    MessageBox.Show("Doctor Succesfully Deleted");
                    FirstName.Text = "";
                    LastName.Text = "";
                    VisitingDays.Text = "";
                    VisitingHours.Text = "";
                    Chamber.Text = "";
                    Degree.Text = "";
                    Department.Text = "";
                    ForAppointment.Text = "";
                    populateData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            new Add_Donor_UI().Show();
            this.Hide();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            new DashBoard().Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
         
            new LoginorSignup().Show();
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            new AdminProfile().Show();
            this.Hide();

        }
    }
}
