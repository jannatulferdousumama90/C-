﻿namespace HMA
{
    public class Admin
    {
        public string FirstName { get; internal set; }
        public string UserName { get; internal set; }
        public string LastName { get; internal set; }
        public string Phone { get; internal set; }
        public string Gender { get; internal set; }
        public int HeightInCm { get; internal set; }
        public int Age { get; internal set; }
        public int WeightInKg { get; internal set; }
        public string BloodGroup { get; internal set; }
        public string Password { get; internal set; }
        public object Contact { get; internal set; }
        public object Blood { get; internal set; }

        public Admin()
        {

        }


        public Admin(string firstName, string lastName, string phone, string BloodGroup, Address address)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Phone = phone;
            this.BloodGroup = BloodGroup;
            this.address = address;
        }

        public Admin(string firstName, string lastName, int id, string phone, string UserName, string Password)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.id = id;
            this.Phone = phone;
            this.UserName = UserName;
            this.Password = Password;
        }
        public Admin(string firstName, string lastName, string password, string userName, int age, int heightInCm, int weightInKg, string gender, string bloodGroup, string phone)
        {
            FirstName = firstName;
            LastName = lastName;
            Password = password;
            UserName = userName;
            Age = age;
            HeightInCm = heightInCm;
            WeightInKg = weightInKg;
            Gender = gender;
            BloodGroup = bloodGroup;
            Phone = phone;

        }
        public int id { get; set; }
        public Address address;
        public Admin(Address address)
        {
            this.address = address;
        }

    }


}