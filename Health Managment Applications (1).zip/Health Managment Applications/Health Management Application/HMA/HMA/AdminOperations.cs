﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HMA
{
    public class AdminOperations
    {
        DBConnection db = new DBConnection();
        public void InsertAdmin()
        {


        }

        public int CheckAdminSignup(int key, string username)
        {
            int count = 0;

            string Query = "select count(*) from AdminSignupTbl where Aid=" + key + " OR UserName='" + username + "'";
            try
            {
                SqlConnection con = new SqlConnection(db.connect); //db.connect
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                count = (Int32)cmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return count;
        }

        public int AdminSIgnup_Ul(string username)
        {
            int count = 0;

            string Query = "select count(*) from AdminTbl where UserName='" + username + "'";
            try
            {
                SqlConnection con = new SqlConnection();
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);

                count = (Int32)cmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return count;
        }

        public int PatientCount()
        {
            int count = 0;

            string Query = "select count(*) from PatientTbl";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                //cmd.ExecuteNonQuery();
                count = (Int32)cmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return count;

        }

        public int DonorCount()
        {
            int count = 0;

            string Query = "select count(*) from DonorTbl";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                //cmd.ExecuteNonQuery();
                count = (Int32)cmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return count;
        }

        public int Doctorcount()
        {
            int count = 0;

            string Query = "select count(*) from DoctorTbl";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                //cmd.ExecuteNonQuery();
                count = (Int32)cmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return count;
        }

     

    
        public Admin GetAdmin(string UserName, string Password)
        {
            Admin A = null;
            String Query = "select Aid,FirstName,LastName,ContactNo,Gender,Age,Height,Weight,BloodGroup,UserName,Password from AdminTbl where UserName='" + UserName + "' COLLATE Latin1_General_CS_AS AND Password='" + Password + "' COLLATE Latin1_General_CS_AS;";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    A = new Admin();
                    A.id = reader.GetInt32(0);
                    A.FirstName = reader.GetString(1);
                    A.LastName = reader.GetString(2);
                    A.Phone = reader.GetString(3);
                    A.Gender = reader.GetString(4);
                    A.Age = reader.GetInt32(5);
                    A.HeightInCm = reader.GetInt32(6);
                    A.WeightInKg = reader.GetInt32(7);
                    A.BloodGroup = reader.GetString(8);
                   
                    A.UserName = reader.GetString(9);

                }
                reader.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return A;
        }
    }

}
        