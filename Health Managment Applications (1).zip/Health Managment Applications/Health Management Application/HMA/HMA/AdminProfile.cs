﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class AdminProfile : Form
    {
        Admin A;
        public AdminProfile()
        {
           // A = Ad;
            InitializeComponent();
        }

       

        private void AdminProfile_Load(object sender, EventArgs e)
        {
            //Name.Text = A.FirstName + " " + A.LastName;
           // Contact.Text = A.Phone;
            //Age.Text = Convert.ToString(A.Age);
           // BloodGroup.Text = A.BloodGroup;
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            new Add_Donor_UI().Show();
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new AddDoctor_UI().Show();
            this.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            new DashBoard().Show();
            this.Close();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Close();
        }
    }
}
