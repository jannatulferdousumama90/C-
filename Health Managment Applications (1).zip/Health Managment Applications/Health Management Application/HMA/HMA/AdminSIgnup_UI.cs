﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class AdminSIgnup_UI : Form
    {
        public AdminSIgnup_UI()
        {
            InitializeComponent();
        }

        private void AdminSIgnup_UI_Load(object sender, EventArgs e)
        {

        }

      

        private void button1_Click(object sender, EventArgs e)
        {
            Admin A = new Admin();
            AdminOperations op = new AdminOperations();

            string s = FirstName.Text;

            int value;

            if (String.IsNullOrEmpty(UserName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(FirstName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (char.IsDigit(s[0]))
            {
                MessageBox.Show("First letter can not be a number !");
            }
            else if (String.IsNullOrEmpty(LastName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(ContactNo.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Gender.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Age.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Height.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Weight.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(BloodGroup.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Password.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (!int.TryParse(Age.Text.ToString(), out value))
            {
                MessageBox.Show("Age  must be a integer!");
            }
            else if (!int.TryParse(Height.Text.ToString(), out value))
            {
                MessageBox.Show("Height must be a integer!");
            }
            else if (!int.TryParse(Weight.Text.ToString(), out value))
            {
                MessageBox.Show("Weight must be a integer!");
            }
            else
            {
               

                A.UserName = UserName.Text;
                if (op.CheckAdminSignup(A.id, A.UserName) >= 1)
                {
                    MessageBox.Show("Username Already Exists, Select Another !");
                }
                else
                {
                    try
                    {
                        A.FirstName = FirstName.Text;
                        A.LastName = LastName.Text;
                        A.Phone = ContactNo.Text;
                        A.Gender = Gender.SelectedItem.ToString();
                        A.Age = Convert.ToInt32(Age.Text);
                        A.HeightInCm = Convert.ToInt32(Height.Text);
                        A.WeightInKg = Convert.ToInt32(Weight.Text);
                        A.BloodGroup = BloodGroup.SelectedItem.ToString();
                        A.Password = Password.Text;
                        op.InsertAdmin();

                        MessageBox.Show("Signup Succes !");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        Console.WriteLine("Provide the Information correctly");
                    }
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();

        }

       
    }

}

