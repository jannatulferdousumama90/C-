﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HMA
{
    public class AppointmentOperations
    {

        DBConnection db = new DBConnection();

        internal DataSet ShowDtAptList()
        {
            throw new NotImplementedException();
        }

        // public DataSet ShowDtAptList(Drid)
        //{
        // string Query = "select * from AppointmentTbl  where  Drid=" + Drid + " AND AppDate>GETDATE()";
        // SqlConnection con = new SqlConnection(db.connect);
        //con.Open();
        // SqlCommand cmd = new SqlCommand(Query, con);
        //SqlDataAdapter sda = new SqlDataAdapter(cmd);
        //DataSet ds = new DataSet();
        //sda.Fill(ds);
        //return ds;
        // }

        internal DataSet ShowDrAptList()
        {
            string Query = "select * from AppointmentTbl"; // where  Drid=" + Drid + " AND AppDate>GETDATE()";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public void SetAppointment(Patient P, Doctor Dr)
        {
            string Query = "insert into AppointmentTbl  values('" + Dr.id + "','" + P.id + "','" + P.FirstName + " " + P.LastName + "','" + P.UserName + "','" + Dr.FirstName + " " + Dr.LastName + "','" + P.Date + "')";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }



        }

        public int CheckAppointmenttxt(int  Pid, int Drid)
        {
            int count = 0;

            string Query = "select count(*) from AppointmentTbl where Drid=" + Drid + " AND Pid=" + Pid + " AND AppDate>GETDATE()";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);

                count = (Int32)cmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return count;

        }

        //public DataSet ShowUpComingApt(int Pid)
       // {
            //string Query = "select * from AppointmentTbl where  Pid=" + Pid + " AND AppDate>GETDATE()";
            //SqlConnection con = new SqlConnection(db.connect);
            //con.Open();
            //SqlCommand cmd = new SqlCommand(Query, con);
           // SqlDataAdapter sda = new SqlDataAdapter(cmd);
           // DataSet ds = new DataSet();
           // sda.Fill(ds);
           // return ds;
       // }

        public DataSet ShowUpComingApt()
        {
            string Query = "select * from AppointmentTbl";// where  Pid=" + Pid + " AND AppDate>GETDATE()";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }


       // public DataSet ShowPrevApt(int Pid)
       // {
           // string Query = "select * from AppointmentTbl where  Pid=" + Pid + " AND AppDate<GETDATE()";
           // SqlConnection con = new SqlConnection(db.connect);
            //con.Open();
           // SqlCommand cmd = new SqlCommand(Query, con);
            //SqlDataAdapter sda = new SqlDataAdapter(cmd);
           // DataSet ds = new DataSet();
           // sda.Fill(ds);
           // return ds;
       // }



        public DataSet ShowPrevApt()
        {
            string Query = "select * from AppointmentTbl";// where  Pid=" + Pid + " AND AppDate<GETDATE()";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }


        public void DeleteApt(int key)
        {
            string Query = "Delete from AppointmentTbl where Pid=" + key + "";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }


       


    }
}



