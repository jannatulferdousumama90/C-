﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class BloodBankUI : Form
    {

        Patient p;
        public BloodBankUI()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            new DonorProfile().Show();
            this.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Show();
        }

        private void SeacrhBtn_Click(object sender, EventArgs e)
        {
            String src = searchtxt.Text;
            DonorOperations OP = new DonorOperations();
            DataSet ds = OP.ShowSpecificDonor(src);
            DonorLitsDGV.DataSource = ds.Tables[0];
        }

        void populateData()
        {
            DonorOperations op = new DonorOperations();
            DataSet ds = op.ShowDonors();
            DonorLitsDGV.DataSource = ds.Tables[0];
        }

        private void BloodBankUI_Load(object sender, EventArgs e)
        {
            populateData();
            DonorLitsDGV.AllowUserToAddRows = false;
            this.DonorLitsDGV.Columns["Did"].Visible = false;
            DonorLitsDGV.Columns["FirstName"].HeaderText = "FirstName";
            DonorLitsDGV.Columns["LastName"].HeaderText = "Last Name";
            DonorLitsDGV.Columns["ContactNo"].HeaderText = "Phone NO.";
            DonorLitsDGV.Columns["BloodGroup"].HeaderText = "Blood GROUP";
            DonorLitsDGV.Columns["City"].HeaderText = "City";
            DonorLitsDGV.Columns["Area"].HeaderText = "Area";

        }
    }
}
