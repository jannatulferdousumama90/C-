﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class BookAppointmentUI : Form
    {

        Patient P;
        int id;
        Doctor Dr = new Doctor();
        public BookAppointmentUI()
        {
            InitializeComponent();
        }

        void populateData()
        {
            DoctorOperations OP = new DoctorOperations();
            DataSet ds = OP.ShowDoctors();
            DoctorApDGV.DataSource = ds.Tables[0];
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new PatientProfile().Show();
            this.Close();
        }

        private void SeeAptpicbox_Click(object sender, EventArgs e)
        {
            new ViewAppointments_UI().Show();
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            new PatientsMedicalHistory_Ul().Show();
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            new CovidPredict_UI().Show();
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Close();
        }

        private void SeacrhBtn_Click(object sender, EventArgs e)
        {
            String src = searchtxt.Text;
            DoctorOperations OP = new DoctorOperations();
            DataSet ds = OP.ShowSpecificDoctor(src);
            DoctorApDGV.DataSource = ds.Tables[0];
        }

        private void DoctorApDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.DoctorApDGV.Rows[e.RowIndex];
                DoctorName.Text = row.Cells["FirstName"].Value.ToString() + " " + row.Cells["LastName"].Value.ToString();
                Department.Text = row.Cells["LastName"].Value.ToString();
                VisitingDays.Text = row.Cells["VisitingDays"].Value.ToString();
                Chamber.Text = row.Cells["Chamber"].Value.ToString();

                Dr.FirstName = row.Cells["FirstName"].Value.ToString();
                Dr.LastName = row.Cells["LastName"].Value.ToString();
                Dr.Department = row.Cells["Department"].Value.ToString();
                Dr.visiting_days = row.Cells["VisitingDays"].Value.ToString();
                Dr.Chammber = row.Cells["Chamber"].Value.ToString();
                Dr.id = Convert.ToInt32(row.Cells["Did"].Value.ToString());
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            P.Date = AptDatePicker.Value.Date;
            AppointmentOperations op = new AppointmentOperations();
            if (String.IsNullOrEmpty(DoctorName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Department.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(VisitingDays.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Chamber.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (AptDatePicker.Value < DateTime.Today)
            {
                MessageBox.Show("Invalid Date!");
            }
            else if (op.CheckAppointmenttxt(P.id, Dr.id) >= 1)
            { 
                MessageBox.Show("Appointment Set Already!");
            }
            else
            {
                try
                {
                    op.SetAppointment(P, Dr);
                    MessageBox.Show("Appointment has been set succesfully.!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
        }

        private void BookAppointmentUI_Load(object sender, EventArgs e)
        {
            populateData();
            DoctorApDGV.AllowUserToAddRows = false;
            this.DoctorApDGV.Columns["Drid"].Visible = false;
            DoctorApDGV.Columns["Drid"].HeaderText = "Drid";
            DoctorApDGV.Columns["FirstName"].HeaderText = "First Name";
            DoctorApDGV.Columns["LastName"].HeaderText = "Last Name";
            DoctorApDGV.Columns["Degree"].HeaderText = "Degree";
            DoctorApDGV.Columns["Department"].HeaderText = "Department";
            DoctorApDGV.Columns["Chamber"].HeaderText = "Chamber";
            DoctorApDGV.Columns["VisitingHours"].HeaderText = "Visiting Hours";
            DoctorApDGV.Columns["Visitingdays"].HeaderText = "Visiting Days";
            DoctorApDGV.Columns["ForAppointment"].HeaderText = "For Appointmnent";
        }
    }
}
