﻿
namespace HMA
{
    partial class CovidPredict_UI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CovidPredict_UI));
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.SeeAptpicbox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.smellchk = new System.Windows.Forms.CheckBox();
            this.breathingchk = new System.Windows.Forms.CheckBox();
            this.nosechk = new System.Windows.Forms.CheckBox();
            this.oxychk = new System.Windows.Forms.CheckBox();
            this.sorethrtchk = new System.Windows.Forms.CheckBox();
            this.Loosechk = new System.Windows.Forms.CheckBox();
            this.painchk = new System.Windows.Forms.CheckBox();
            this.chestchk = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Yellowpicbox = new System.Windows.Forms.PictureBox();
            this.GreenPicbox = new System.Windows.Forms.PictureBox();
            this.Redpicbox = new System.Windows.Forms.PictureBox();
            this.Resultlb = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SeeAptpicbox)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowpicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GreenPicbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redpicbox)).BeginInit();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(152, 685);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 24);
            this.label10.TabIndex = 39;
            this.label10.Text = "Log Out";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(142, 529);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(153, 24);
            this.label9.TabIndex = 38;
            this.label9.Text = "Medical History";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(124, 371);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(171, 24);
            this.label8.TabIndex = 37;
            this.label8.Text = "See Appointment";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(124, 257);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(181, 24);
            this.label7.TabIndex = 36;
            this.label7.Text = "Book Appointment";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(124, 173);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 24);
            this.label6.TabIndex = 35;
            this.label6.Text = "Patient";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(104, 50);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(123, 98);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 34;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.DarkRed;
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(42, 671);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(104, 96);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 33;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(39, 477);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(86, 127);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 32;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(39, 355);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(79, 90);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // SeeAptpicbox
            // 
            this.SeeAptpicbox.BackColor = System.Drawing.Color.White;
            this.SeeAptpicbox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SeeAptpicbox.BackgroundImage")));
            this.SeeAptpicbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SeeAptpicbox.Location = new System.Drawing.Point(39, 225);
            this.SeeAptpicbox.Name = "SeeAptpicbox";
            this.SeeAptpicbox.Size = new System.Drawing.Size(79, 94);
            this.SeeAptpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SeeAptpicbox.TabIndex = 30;
            this.SeeAptpicbox.TabStop = false;
            this.SeeAptpicbox.Click += new System.EventHandler(this.SeeAptpicbox_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(446, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(305, 24);
            this.label1.TabIndex = 243;
            this.label1.Text = "Select the symptoms you have :";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.SeeAptpicbox);
            this.panel1.Location = new System.Drawing.Point(-30, -15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(318, 796);
            this.panel1.TabIndex = 241;
            // 
            // smellchk
            // 
            this.smellchk.AutoSize = true;
            this.smellchk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.smellchk.Location = new System.Drawing.Point(464, 146);
            this.smellchk.Name = "smellchk";
            this.smellchk.Size = new System.Drawing.Size(201, 27);
            this.smellchk.TabIndex = 244;
            this.smellchk.Text = "Loss of test or smell";
            this.smellchk.UseVisualStyleBackColor = true;
            // 
            // breathingchk
            // 
            this.breathingchk.AutoSize = true;
            this.breathingchk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breathingchk.Location = new System.Drawing.Point(464, 205);
            this.breathingchk.Name = "breathingchk";
            this.breathingchk.Size = new System.Drawing.Size(229, 27);
            this.breathingchk.TabIndex = 245;
            this.breathingchk.Text = "Difficulties in breathing";
            this.breathingchk.UseVisualStyleBackColor = true;
            // 
            // nosechk
            // 
            this.nosechk.AutoSize = true;
            this.nosechk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nosechk.Location = new System.Drawing.Point(464, 264);
            this.nosechk.Name = "nosechk";
            this.nosechk.Size = new System.Drawing.Size(133, 27);
            this.nosechk.TabIndex = 246;
            this.nosechk.Text = "Runny Nose";
            this.nosechk.UseVisualStyleBackColor = true;
            // 
            // oxychk
            // 
            this.oxychk.AutoSize = true;
            this.oxychk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oxychk.Location = new System.Drawing.Point(464, 318);
            this.oxychk.Name = "oxychk";
            this.oxychk.Size = new System.Drawing.Size(301, 27);
            this.oxychk.TabIndex = 247;
            this.oxychk.Text = "Oxygen level decreasing rapidly";
            this.oxychk.UseVisualStyleBackColor = true;
            // 
            // sorethrtchk
            // 
            this.sorethrtchk.AutoSize = true;
            this.sorethrtchk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sorethrtchk.Location = new System.Drawing.Point(464, 369);
            this.sorethrtchk.Name = "sorethrtchk";
            this.sorethrtchk.Size = new System.Drawing.Size(128, 27);
            this.sorethrtchk.TabIndex = 248;
            this.sorethrtchk.Text = "Sore throat";
            this.sorethrtchk.UseVisualStyleBackColor = true;
            // 
            // Loosechk
            // 
            this.Loosechk.AutoSize = true;
            this.Loosechk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Loosechk.Location = new System.Drawing.Point(464, 427);
            this.Loosechk.Name = "Loosechk";
            this.Loosechk.Size = new System.Drawing.Size(128, 27);
            this.Loosechk.TabIndex = 249;
            this.Loosechk.Text = "Loose stool";
            this.Loosechk.UseVisualStyleBackColor = true;
            // 
            // painchk
            // 
            this.painchk.AutoSize = true;
            this.painchk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.painchk.Location = new System.Drawing.Point(464, 477);
            this.painchk.Name = "painchk";
            this.painchk.Size = new System.Drawing.Size(166, 27);
            this.painchk.TabIndex = 250;
            this.painchk.Text = "Aches and pains";
            this.painchk.UseVisualStyleBackColor = true;
            // 
            // chestchk
            // 
            this.chestchk.AutoSize = true;
            this.chestchk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chestchk.Location = new System.Drawing.Point(464, 538);
            this.chestchk.Name = "chestchk";
            this.chestchk.Size = new System.Drawing.Size(121, 27);
            this.chestchk.TabIndex = 251;
            this.chestchk.Text = "Chest pain";
            this.chestchk.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1.BackColor = System.Drawing.Color.Teal;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(957, 601);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 48);
            this.button1.TabIndex = 252;
            this.button1.Text = "SUBMIT";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // Yellowpicbox
            // 
            this.Yellowpicbox.BackColor = System.Drawing.Color.Lime;
            this.Yellowpicbox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Yellowpicbox.BackgroundImage")));
            this.Yellowpicbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Yellowpicbox.Location = new System.Drawing.Point(731, 601);
            this.Yellowpicbox.Name = "Yellowpicbox";
            this.Yellowpicbox.Size = new System.Drawing.Size(167, 111);
            this.Yellowpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Yellowpicbox.TabIndex = 253;
            this.Yellowpicbox.TabStop = false;
            this.Yellowpicbox.Visible = false;
            this.Yellowpicbox.Click += new System.EventHandler(this.Yellowpicbox_Click);
            // 
            // GreenPicbox
            // 
            this.GreenPicbox.BackColor = System.Drawing.Color.Yellow;
            this.GreenPicbox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GreenPicbox.BackgroundImage")));
            this.GreenPicbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.GreenPicbox.Location = new System.Drawing.Point(526, 601);
            this.GreenPicbox.Name = "GreenPicbox";
            this.GreenPicbox.Size = new System.Drawing.Size(167, 111);
            this.GreenPicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GreenPicbox.TabIndex = 254;
            this.GreenPicbox.TabStop = false;
            this.GreenPicbox.Visible = false;
            // 
            // Redpicbox
            // 
            this.Redpicbox.BackColor = System.Drawing.Color.Red;
            this.Redpicbox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Redpicbox.BackgroundImage")));
            this.Redpicbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Redpicbox.Location = new System.Drawing.Point(323, 601);
            this.Redpicbox.Name = "Redpicbox";
            this.Redpicbox.Size = new System.Drawing.Size(167, 111);
            this.Redpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Redpicbox.TabIndex = 255;
            this.Redpicbox.TabStop = false;
            this.Redpicbox.Visible = false;
            // 
            // Resultlb
            // 
            this.Resultlb.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Resultlb.BackColor = System.Drawing.Color.Teal;
            this.Resultlb.FlatAppearance.BorderSize = 2;
            this.Resultlb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Resultlb.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Resultlb.ForeColor = System.Drawing.Color.White;
            this.Resultlb.Location = new System.Drawing.Point(957, 670);
            this.Resultlb.Name = "Resultlb";
            this.Resultlb.Size = new System.Drawing.Size(197, 48);
            this.Resultlb.TabIndex = 256;
            this.Resultlb.Text = "RESULT";
            this.Resultlb.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(332, 728);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 24);
            this.label2.TabIndex = 257;
            this.label2.Text = "High Chances ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(546, 728);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 24);
            this.label3.TabIndex = 258;
            this.label3.Text = "Mild Chances";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(748, 728);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 24);
            this.label4.TabIndex = 259;
            this.label4.Text = "Less Chances";
            // 
            // CovidPredict_UI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1166, 781);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Resultlb);
            this.Controls.Add(this.Redpicbox);
            this.Controls.Add(this.GreenPicbox);
            this.Controls.Add(this.Yellowpicbox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chestchk);
            this.Controls.Add(this.painchk);
            this.Controls.Add(this.Loosechk);
            this.Controls.Add(this.sorethrtchk);
            this.Controls.Add(this.oxychk);
            this.Controls.Add(this.nosechk);
            this.Controls.Add(this.breathingchk);
            this.Controls.Add(this.smellchk);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CovidPredict_UI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CovidPredict_UI";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SeeAptpicbox)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowpicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GreenPicbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redpicbox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox SeeAptpicbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox smellchk;
        private System.Windows.Forms.CheckBox breathingchk;
        private System.Windows.Forms.CheckBox nosechk;
        private System.Windows.Forms.CheckBox oxychk;
        private System.Windows.Forms.CheckBox sorethrtchk;
        private System.Windows.Forms.CheckBox Loosechk;
        private System.Windows.Forms.CheckBox painchk;
        private System.Windows.Forms.CheckBox chestchk;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox Yellowpicbox;
        private System.Windows.Forms.PictureBox GreenPicbox;
        private System.Windows.Forms.PictureBox Redpicbox;
        private System.Windows.Forms.Button Resultlb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}