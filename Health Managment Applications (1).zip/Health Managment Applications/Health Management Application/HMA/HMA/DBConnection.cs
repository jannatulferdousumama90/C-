﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMA
{
    class DBConnection
    {
        public string connect = "Data Source=DESKTOP-MFUNAFT;Initial Catalog=Health Management Application;Integrated Security=True";
    }
}
