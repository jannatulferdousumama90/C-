﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class DashBoard : Form
    {

        

        public DashBoard()
        {
            InitializeComponent();
        }

        public object donorcount { get; set; }

        private void DashBoard_Load(object sender, EventArgs e)
        {
            AdminOperations op = new AdminOperations();
            dtcount.Text = Convert.ToString(op.Doctorcount());
            donorcount = Convert.ToString(op.DonorCount());
            patcountlb.Text = Convert.ToString(op.PatientCount());
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            new AdminProfile().Show();
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            new AddDoctor_UI().Show();
            this.Close();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new Add_Donor_UI().Show();
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Close();
        }
    }
}
