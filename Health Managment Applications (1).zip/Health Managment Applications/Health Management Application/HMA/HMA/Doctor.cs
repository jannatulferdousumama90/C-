﻿namespace HMA
{
    public class Doctor 
    {
        public string Degree { get; set; }
        public string Department { get; set; }
        public string Chammber { get; set; }
        public string visiting_days { get; set; }
        public string Visitng_Hours { get; set; }
        public string Appoinment_CallNo { get; set; }
        public string FirstName { get; set; }

        public int id { get; set; }
        public string LastName { get; set; }
        public string Password { get; set; }
        public string UserName { get; set; }
        public int Age { get; set; }
        public int HeightInCm { get; set; }
        public int WeightInKg { get; set; }

        public string Gender { get; set; }

        public string BloodGroup { get; set; }

        public string Phone { get; set; }

        public Doctor()
        {

        }

        public Doctor(string firstName, string lastName, string phone, string BloodGroup, Address address)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Phone = phone;
            this.BloodGroup = BloodGroup;
            this.address = address;
        }

        public Doctor(string firstName, string lastName, int id, string phone, string UserName, string Password)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.id = id;
            this.Phone = phone;
            this.UserName = UserName;
            this.Password = Password;
        }
        public Doctor(string firstName, string lastName, string password, string userName, int age, int heightInCm, int weightInKg, string gender, string bloodGroup, string phone)
        {
            FirstName = firstName;
            LastName = lastName;
            Password = password;
            UserName = userName;
            Age = age;
            HeightInCm = heightInCm;
            WeightInKg = weightInKg;
            Gender = gender;
            BloodGroup = bloodGroup;
            Phone = phone;

        }
        
        public Address address;
        public Doctor(Address address)
        {
            this.address = address;
        }

    }
}