﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HMA
{
    public class DoctorOperations
    {
        DBConnection db = new DBConnection();
        public int CheckDoctorSignup(int key, string username)
        {
            int count = 0;

            string Query = "select count(*) from DoctorSignupTbl where Drid=" + key + " OR UserName='" + username + "'";
            try
            {
                SqlConnection con = new SqlConnection(db.connect); 
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                count = (Int32)cmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return count;
        }

        public void DoctorSIgnup_UI(Doctor Dr)
        {
            string Query = "insert into DoctorSignupTbl  values('" + Dr.id + "','" + Dr.FirstName + "','" + Dr.LastName + "','" + Dr.Degree + "','" + Dr.Department + "','" + Dr.Chammber + "','" + Dr.Visitng_Hours + "','" + Dr.visiting_days + "','" + Dr.Appoinment_CallNo + "','" + Dr.UserName + "','" + Dr.Password + "')";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }



        public void InsertDoctor(Doctor Dr)
        {
            string Query = "insert into DoctorTbl  values('" + Dr.FirstName + "','" + Dr.LastName + "','" + Dr.Degree + "','" + Dr.Department + "','" + Dr.Chammber + "','" + Dr.Visitng_Hours + "','" + Dr.visiting_days + "','" + Dr.Appoinment_CallNo + "')";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public DataSet ShowDoctors()
        {
            string Query = "select *from DoctorTbl";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public void UpdateDoctors(object key, Doctor Dr)
        {
            string Query = "Update DoctorTbl set FirstName='" + Dr.FirstName + "',LastName='" + Dr.LastName + "',Degree='" + Dr.Degree + "',Department='" + Dr.Department + "',Chamber='" + Dr.Chammber + "',VisitingHours='" + Dr.Visitng_Hours + "',VisitingDays='" + Dr.visiting_days + "',='" + Dr.Appoinment_CallNo + "' where Drid=" + key + ";";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);

            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void DeleteDoctors(int key)
        {
            string Query = "Delete from DoctorTbl where Drid=" + key + "";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public DataSet ShowSpecificDoctor(string src)
        {
            string Query = "select * from  where  lower(Department) like '%" + src + "%' OR UPPER(Department) like '%" + src + "%'";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public Doctor GetDoctor(string UserName, string Password)
        {
            Doctor Dr = null;
            String Query = "select Drid,FirstName,LastName,Degree,Department,Chamber,VisitingHours,VisitingHours,ForAppointment from DoctorSignupTbl where UserName='" + UserName + "' COLLATE Latin1_General_CS_AS  AND Password='" + Password + "' COLLATE Latin1_General_CS_AS ;";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Dr = new Doctor();
                    Dr.id = reader.GetInt32(0);
                    Dr.FirstName = reader.GetString(1);
                    Dr.LastName = reader.GetString(2);
                    Dr.Degree = reader.GetString(3);
                    Dr.Department = reader.GetString(4);
                    Dr.Chammber = reader.GetString(5);
                    Dr.Visitng_Hours = reader.GetString(6);
                    Dr.visiting_days = reader.GetString(7);
                    Dr.Appoinment_CallNo = reader.GetString(8);

                }
                reader.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return Dr;

        }
    }
}
