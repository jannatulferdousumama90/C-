﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class DoctorProfile : Form
    {
        Doctor Dr;
        public DoctorProfile()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new TreatmentUI().Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            new ViewAppointmentlist_UI().Show();
            this.Hide();

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Hide();
        }

        private void DoctorProfile_Load(object sender, EventArgs e)
        {
           // Name.Text = Dr.FirstName + " " + Dr.LastName;
            //Department.Text = Dr.Department;
            //VisitingDays.Text = Dr.visiting_days;
           // Chamber.Text = Dr.Chammber;
            //VisitingHours.Text = Dr.Visitng_Hours;
           

        }
    }
}
