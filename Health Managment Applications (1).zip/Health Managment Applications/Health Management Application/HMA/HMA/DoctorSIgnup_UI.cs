﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class DoctorSIgnup_UI : Form
    {
        public object OP { get; private set; }

        public DoctorSIgnup_UI()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        

        private void button1_Click(object sender, EventArgs e)
        {

            Doctor Dr = new Doctor();
            DoctorOperations op = new DoctorOperations();

            string s = FirstName.Text;


            int value;

            if (String.IsNullOrEmpty(FirstName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(LastName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Degree.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Department.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Chambar.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(VisitingHours.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(VisitingDays.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(ForAppointment.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }

            else if (String.IsNullOrEmpty(Password.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(UserName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }

            else if (Password.Text.Length < 5)
            {
                MessageBox.Show("Password is too weak !");
            }


            else
            {
                Dr.UserName = UserName.Text;
                if (op.CheckDoctorSignup(Dr.id, Dr.UserName) < 1)
                {
                    try
                    {
                        Dr.FirstName = FirstName.Text;
                        Dr.LastName = LastName.Text;
                        Dr.Degree = Degree.Text;
                        Dr.Department = Department.Text;
                        Dr.Chammber = Chambar.Text;
                        Dr.Visitng_Hours = VisitingHours.Text;
                        Dr.visiting_days = VisitingDays.Text;
                        Dr.Appoinment_CallNo = ForAppointment.Text;
                        Dr.Password = Password.Text;
                        //
                        //OP.DoctorSignup(Dr);
                        MessageBox.Show("Sign up Succes !");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }

                else
                {
                    MessageBox.Show("This Doctor Already Exists in the system");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
        }

        private void DoctorSIgnup_UI_Load(object sender, EventArgs e)
        {

        }
    }
}
