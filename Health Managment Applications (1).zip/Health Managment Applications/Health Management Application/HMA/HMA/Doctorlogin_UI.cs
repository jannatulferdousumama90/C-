﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HMA
{
    public partial class Doctorlogin_UI : Form
    {
        int Persontype;

   

        public Doctorlogin_UI()
        {
          //  Persontype = p.PersonType;
            InitializeComponent();
            Password.PasswordChar = 'x';
        }



        private void Doctorlogin_UI_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string pass = Password.Text;
            string user = UserName.Text;
            if (Password.Text == " " || UserName.Text == "")
            {
                MessageBox.Show("Provide User name and Password");
            }
            else
            {

               // if (Persontype == 2)
                //{
                    DoctorOperations op = new DoctorOperations();
                    Doctor Dr = op.GetDoctor(user, pass);

                    if (Dr == null)
                    {
                        MessageBox.Show("Credentials Incorrect");

                    }

                    else
                    {
                        MessageBox.Show("Login Succesful ! ," + Dr.FirstName);
                        new DoctorProfile().Show();
                        this.Close();
                    }

                //}
               // else
                //{
                   // MessageBox.Show("Credentials Incorrect");
                //}

                }


                    //this.Close();
                }

        private void button2_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Close();

        }
    }




     

 }


  

