﻿namespace HMA
{
    public class Donor 
    {
        

        public Donor()
        {


        }

      

        public string FirstName { get; set; }
        public string UserName { get;  set; }
        public string LastName { get;  set; }
        public string Phone { get;  set; }
        public string Gender { get;  set; }
        public int Age { get;  set; }
        public int HeightInCm { get; set; }
        public int WeightInKg { get; set; }
        public string BloodGroup { get; set; }

        public Address address;
       public string city;
        public string area;

        public int id { get; set; }

        public string Password { get; set; }
        public string Address { get; set; }
        public string Dphone { get; set; }
        public string DBGrp { get; set; }
        public string Dcity { get; set; }
        public string Darea { get;  set; }
        public string LdDoned { get; internal set; }

        public Donor(string firstName, string lastName, string phone, string BloodGroup, Address address)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Phone = phone;
            this.BloodGroup = BloodGroup;
            this.address = address;
        }

        public Donor(string firstName, string lastName, int id, string phone, string UserName, string Password)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.id = id;
            this.Phone = phone;
            this.UserName = UserName;
            this.Password = Password;
        }
        public Donor(string firstName, string lastName, string password, string userName, int age, int heightInCm, int weightInKg, string gender, string bloodGroup, string phone)
        {
            FirstName = firstName;
            LastName = lastName;
            Password = password;
            UserName = userName;
            Age = age;
            HeightInCm = heightInCm;
            WeightInKg = weightInKg;
            Gender = gender;
            BloodGroup = bloodGroup;
            Phone = phone;

        }






        


        public Donor(Address address)
        {
            this.address = address;
        }

    }
}