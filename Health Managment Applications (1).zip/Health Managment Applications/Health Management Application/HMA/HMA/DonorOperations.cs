﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HMA
{
    public class DonorOperations
    {

       
        DBConnection db = new DBConnection();
        public int CheckDonorSignup(int key,string UserName)
        {
            int count = 0;

            string Query = "select count(*) from DonorSignupTbl where Did=" + key + " OR UserName='" + UserName + "'";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                count = (Int32)cmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return count;

        }

      public void UpdateDonors(int key, Donor D)
        {
            string Query = "Update DonorTbl set FirstName ='" + D.FirstName + "',LastName='" + D.LastName + "',Phone='" + D.Phone + "',BloodGroup='" + D.BloodGroup + "',City='" + D.address.City + "',Area='" + D.address.Area + "' where Did=" + key + ";";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);

            cmd.ExecuteNonQuery();
            con.Close();
        }

        public DataSet ShowDonors()
        {
            string Query = "select *from DonorTbl";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public void InsertDonor(Donor D)
        {
            string Query = "insert into DonorTbl"; // values('" + D.FirstName + "','" + D.LastName + "','" + D.Phone + "','" + D.BloodGroup + "','" + D.address.City + "','" + D.address.Area + "')";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public void DeleteDonors(int key)
        {
            string Query = "Delete from DonorTbl where Did=" + key + "";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);
            cmd.ExecuteNonQuery();
            con.Close();

        }

        public DataSet ShowSpecificDonor(string src)
        {
            string Query = "select * from DonorTbl where BloodGroup  like '%" + src + "%' OR lower(BloodGroup) like '%" + src + "%' ";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public Donor GetDonor(string UserName, string Password)
        {
            Donor D = null;
            String Query = "select Did,FirstName,LastName ,ContactNo,Gender,Age,Height,Weight,BloodGroup,UserName,Password,LastdateofDonedBlood from DonorTbl where UserName='" + UserName + "' COLLATE Latin1_General_CS_AS AND Password='" + Password + "' COLLATE Latin1_General_CS_AS;";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    D = new Donor();
                    D.id = reader.GetInt32(0);
                    D.FirstName = reader.GetString(1);
                    D.LastName = reader.GetString(2);
                    D.Phone = reader.GetString(3);
                    D.Gender = reader.GetString(4);
                    D.Age = reader.GetInt32(5);
                    D.HeightInCm = reader.GetInt32(6);
                    D.WeightInKg = reader.GetInt32(7);
                    D.BloodGroup = reader.GetString(8);
                    D.LdDoned = reader.GetString(10);

                    D.UserName = reader.GetString(9);


                }
                reader.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return D;
        }
    }

}
