﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class DonorProfile : Form
    {

        Donor D;
        public DonorProfile()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new BloodBankUI().Show();
            this.Show();

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Show();
        }

        private void DonorProfile_Load(object sender, EventArgs e)
        {
            //Name.Text = D.FirstName + " " + D.LastName;
           // Contact.Text = D.Phone;
           // Age.Text = Convert.ToString(D.Age);
            //BloodGroup.Text = D.BloodGroup;
           // LastdateofDonedBlood.Text = D.LdDoned;
        }
    }
}
