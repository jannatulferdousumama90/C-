﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class DonorSignup_UI : Form
    {
        public DonorSignup_UI()
        {
            InitializeComponent();
        }

       
        private void DonorSignup_UI_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Donor D = new Donor();
            DonorOperations op = new DonorOperations();

            string s = FirstName.Text;

            int value;

            if (String.IsNullOrEmpty(UserName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(FirstName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (char.IsDigit(s[0]))
            {
                MessageBox.Show("First letter can not be a number !");
            }
            else if (String.IsNullOrEmpty(LastName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(ContactNo.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Gender.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Age.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(LastdateofDonedBlood.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Height.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Weight.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(BloodGroup.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Password.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(LastdateofDonedBlood.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (!int.TryParse(Age.Text.ToString(), out value))
            {
                MessageBox.Show("Age  must be a integer!");
            }
           // else if (!int.TryParse(LdDoned.Text.ToString(), out value))
            //{
                //MessageBox.Show("LdDonor  must be a integer!");
            //}
            else if (!int.TryParse(Height.Text.ToString(), out value))
            {
                MessageBox.Show("Height must be a integer!");
            }
            else if (!int.TryParse(Weight.Text.ToString(), out value))
            {
                MessageBox.Show("Weight must be a integer!");
            }
            
            else
            {

                D.UserName = UserName.Text;
                if (op.CheckDonorSignup(D.id, D.UserName) < 1)
                {

                    try
                    {
                        D.FirstName = FirstName.Text;
                        D.LastName = LastName.Text;
                        D.Phone = ContactNo.Text;
                        D.Gender = Gender.SelectedItem.ToString();
                        D.Age = Convert.ToInt32(Age.Text);
                        D.HeightInCm = Convert.ToInt32(Height.Text);
                        D.WeightInKg = Convert.ToInt32(Weight.Text);
                        D.BloodGroup = BloodGroup.SelectedItem.ToString();
                        D.Password = Password.Text;
                        D.LdDoned = LastdateofDonedBlood.Text;
                        //LdDoned.Text = D.LdDoned;
                        // op.InsertAdmin();

                        MessageBox.Show("Signup Succes !");
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }

                else
                {
                    MessageBox.Show("This Admin Already Exists in the system");
                }
            }


        }


        private void button2_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
