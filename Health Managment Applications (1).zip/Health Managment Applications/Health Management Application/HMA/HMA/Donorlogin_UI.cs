﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HMA
{
    public partial class Donorlogin_UI : Form
    {

        int persontype;
        public Donorlogin_UI()
        {
            //persontype = p. PersonType;
            InitializeComponent();
            Password.PasswordChar = 'x';
        }


        //this.Close();

        public int DonorSignup_UI { get; private set; }

        private void button1_Click(object sender, EventArgs e)
        {
            string pass = Password.Text;
            string user = UserName.Text;
            if (Password.Text == " " || UserName.Text == "")
            {
                MessageBox.Show("Provide User name and Password");
            }
            else
            {

              // if (persontype == 4)
               // {
                    DonorOperations op = new DonorOperations();
                    Donor D = op.GetDonor(user, pass);


                    if (D == null)
                    {
                        MessageBox.Show("Credentials Incorrect");
                    }
                    else
                    {
                        MessageBox.Show("Login Successful !, " + D.FirstName);
                        new DonorProfile().Show();
                        this.Close();
                    }
               // }
               // else
                //{
                   // MessageBox.Show("Credentials Incorrect");
               // }

            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Close();

        }
    }

        //private void button2_Click(object sender, EventArgs e)
        //{
           // new LoginorSignup().Show();
           // this.Close();
       // }

       
    }


