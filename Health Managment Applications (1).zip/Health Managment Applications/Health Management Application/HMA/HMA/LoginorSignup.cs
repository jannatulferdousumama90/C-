﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class LoginorSignup : Form
    {

        Person p = new Person();
        public LoginorSignup()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void loginorsignup_Load(object sender, EventArgs e)
        {
            p.PersonType = 4;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Select the role");
            }

            else
            {
                string s = comboBox1.SelectedItem.ToString();
                if (s == "Admin")
                {
                    p.PersonType = 1;
                }
                else if (s == "Doctor")
                {
                    p.PersonType = 2;
                }
                else if (s == "Patient")
                {
                    p.PersonType = 3;
                }
                else if (s == "Donor")
                {
                    p.PersonType = 4;
                }



            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Select the role");
            }

            else
            {
                string s = comboBox1.SelectedItem.ToString();
                if (s == "Admin")
                {
                    p.PersonType = 1;
                }
                else if (s == "Doctor")
                {
                    p.PersonType = 2;
                }
                else if (s == "Patient")
                {
                    p.PersonType = 3;
                }
                else if (s == "Donor")
                {
                    p.PersonType = 4;
                }
                if (p.PersonType == 1)
                {
                    new Adminlogin_UI().Show();
                    this.Hide();
                }

                else if (p.PersonType == 2)
                {
                    new Doctorlogin_UI().Show();
                    this.Hide();
                }
                else if (p.PersonType == 3)
                {
                    new Patientlogin_UI().Show();
                    this.Hide();
                }
                else if (p.PersonType == 4)
                {
                    new Donorlogin_UI().Show();
                    this.Hide();
                }




            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //new Login_UI().Show();
            //this.Hide();
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Select the role");
            }

            else
            {
                string s = comboBox1.SelectedItem.ToString();
                if (s == "Admin")
                {
                    p.PersonType = 1;
                }
                else if (s == "Doctor")
                {
                    p.PersonType = 2;
                }
                else if (s == "Patient")
                {
                    p.PersonType = 3;
                }
                else if (s == "Donor")
                {
                    p.PersonType = 4;
                }
                if (p.PersonType == 1)
                {
                    new AdminSIgnup_UI().Show();
                    this.Hide();
                }

                else if (p.PersonType == 2)
                {
                    new DoctorSIgnup_UI().Show();
                    this.Hide();
                }
                else if (p.PersonType == 3)
                {
                    new PatientSignup_UI().Show();
                    this.Hide();
                }
                else if (p.PersonType == 4)
                {
                    new DonorSignup_UI().Show();
                    this.Hide();
                }

            }
        }

        internal class Person
        {
            public int PersonType { get; internal set; }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
