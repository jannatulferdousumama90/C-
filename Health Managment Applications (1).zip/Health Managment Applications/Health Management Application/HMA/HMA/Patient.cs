﻿using System;

namespace HMA
{
    public class Patient
    {
       

        public string Diseases;
        public DateTime Date;
        public string Prescription;
        public Patient()
        {

        }


        public int id { get; set; }
        public string FirstName { get; set; }
        public string UserName { get; set; }
        public string LastName { get;  set; }
        public string Phone { get; set; }
        public string Gender { get;  set; }
        public int Age { get; set; }
        public int HeightInCm { get;  set; }
        public int WeightInKg { get; set; }
        public string BloodGroup { get;  set; }
        public string Password { get;  set; }


        public Patient(string firstName, string lastName, string phone, string BloodGroup, Address address)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Phone = phone;
            this.BloodGroup = BloodGroup;
            this.address = address;
        }

        public Patient(string firstName, string lastName, int id, string phone, string UserName, string Password)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.id = id;
            this.Phone = phone;
            this.UserName = UserName;
            this.Password = Password;
        }
        public Patient(string firstName, string lastName, string password, string userName, int age, int heightInCm, int weightInKg, string gender, string bloodGroup, string phone)
        {
            FirstName = firstName;
            LastName = lastName;
            Password = password;
            UserName = userName;
            Age = age;
            HeightInCm = heightInCm;
            WeightInKg = weightInKg;
            Gender = gender;
            BloodGroup = bloodGroup;
            Phone = phone;

        }
        public Address address;
        public Patient(Address address)
        {
            this.address = address;
        }

    }
}