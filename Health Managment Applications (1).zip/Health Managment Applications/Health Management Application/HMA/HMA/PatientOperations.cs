﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HMA
{
     public class PatientOperations
    {
        
        DBConnection db = new DBConnection();
        public int CheckPatientSignup(int key,string username)
        {
            int count = 0;

            string Query = "select count(*) from PatientSignupTbl where Pid=" + key + " OR UserName='" + username + "'";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                count = (Int32)cmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return count;
        }

        public void InsertPatient(Patient P)
        {
            string Query = "insert into PatientTbl  values('" + P.FirstName + "','" + P.LastName + "','" + P.Phone + "','" + P.Gender + "','" + P.Age + "','" + P.HeightInCm + "','" + P.WeightInKg + "','" + P.BloodGroup + "','" + P.Diseases + "','" + P.UserName + "','" + P.Password + "')";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        public Patient GetPatient(String UserName, String Password)
        {
            Patient P = null;
            String Query = "select Pid,FirstName,LastName,ContactNo,Gender,Age,Height,Weight,BloodGroup,Disease,UserName,Password from PatientTbl where UserName='" + UserName + "' COLLATE Latin1_General_CS_AS AND Password='" + Password + "' COLLATE Latin1_General_CS_AS;";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    P = new Patient();
                    P.id = reader.GetInt32(0);
                    P.FirstName = reader.GetString(1);
                    P.LastName = reader.GetString(2);
                    P.Phone = reader.GetString(3);
                    P.Gender = reader.GetString(4);
                    P.Age = reader.GetInt32(5);
                    P.HeightInCm = reader.GetInt32(6);
                    P.WeightInKg = reader.GetInt32(7);
                    P.BloodGroup = reader.GetString(8);
                    P.Diseases = reader.GetString(9);
                    P.UserName = reader.GetString(10);

                }
                reader.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return P;
        }

            public void PatientSignup_Ul(Patient P)
            {
                string Query = "insert into PatientSignupTbl  values('" + P.id + "','" + P.FirstName + "','" + P.LastName + "','" + P.Phone + "','" + P.Gender + "','" + P.Age + "','" + P.HeightInCm + "','" + P.WeightInKg + "','" + P.BloodGroup + "','" + P.Diseases + "','" + P.UserName + "','" + P.Password + "')";
                try
                {
                    SqlConnection con = new SqlConnection(db.connect);
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }

