﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class PatientProfile : Form
    {
        Patient P;
        public PatientProfile()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            new BookAppointmentUI().Show();
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new ViewAppointments_UI ().Show();
            this.Close();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new PatientsMedicalHistory_Ul().Show();
            this.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            new CovidPredict_UI().Show();
            this.Close();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Close();
        }

        private void PatientProfile_Load(object sender, EventArgs e)
        {
           // Nametxt.Text = P.FirstName + " " + P.LastName;
            //Contacttxt.Text = P.Phone;
            //Agetxt.Text = Convert.ToString(P.Age);
            //BloodGroup.Text = P.BloodGroup;
            //CurrentDisease.Text = P.Diseases;

        }
    }
}
