﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class PatientSignup_UI : Form
    {
        public PatientSignup_UI()
        {
            InitializeComponent();
        }

        private void PatientSignup_UI_Load(object sender, EventArgs e)
        {

        }
        string Disease = "";
        bool chk = false;


      

        private void button1_Click(object sender, EventArgs e)
        {
            Patient P = new Patient();
            PatientOperations op = new PatientOperations();

            string s = FirstName.Text;

            int value;

            if (String.IsNullOrEmpty(UserName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(FirstName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (char.IsDigit(s[0]))
            {
                MessageBox.Show("First letter can not be a number !");
            }
            else if (String.IsNullOrEmpty(LastName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(ContactNo.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Gender.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Age.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Height.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Weight.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(BloodGroup.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Password.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (!int.TryParse(Age.Text.ToString(), out value))
            {
                MessageBox.Show("Age  must be a integer!");
            }
            else if (!int.TryParse(Height.Text.ToString(), out value))
            {
                MessageBox.Show("Height must be a integer!");
            }
            else if (!int.TryParse(Weight.Text.ToString(), out value))
            {
                MessageBox.Show("Weight must be a integer!");
            }
            else if (chk == false)
            {
                MessageBox.Show("Disease Fild can not be Empty !");
            }
            else if (Password.Text.Length < 5)
            {
                MessageBox.Show("Password is too weak !");
            }

            else
            {
                P.UserName = UserName.Text;
                if (op.CheckPatientSignup(P.id, P.UserName) >= 1)
                {
                    MessageBox.Show("Username Already Exists, Select Another !");
                }
                else
                {
                    try
                    {
                        P.FirstName = FirstName.Text;
                        P.LastName = LastName.Text;
                        P.Phone = ContactNo.Text;
                        P.Gender = Gender.SelectedItem.ToString();
                        P.Age = Convert.ToInt32(Age.Text);
                        P.HeightInCm = Convert.ToInt32(Height.Text);
                        P.WeightInKg = Convert.ToInt32(Weight.Text);
                        P.BloodGroup = BloodGroup.SelectedItem.ToString();
                        P.Password = Password.Text;
                        P.Diseases = Disease;

                        MessageBox.Show("Signup Succes !");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        Console.WriteLine("Provide the Information correctly");
                    }
                }

            }
        }
        private void checkpressureb_CheckedChanged(object sender, EventArgs e)
        {
            if (checkpressureb.Checked == true)
            {
                checknoneb.Checked = false;
                chk = true;
                Disease = Disease + " " + "Blood Pressure";
            }
            else
            {
                Disease = (Disease.Replace("Blood Pressure", ""));
                chk = false;
            }
        }



        private void checksugerb_CheckedChanged(object sender, EventArgs e)
        {
            if (checksugerb.Checked == true)
            {
                checknoneb.Checked = false;
                chk = true;
                Disease = Disease + "  " + "Diabetes";
            }
            else
            {
                Disease = (Disease.Replace("Diabetes", ""));
                chk = false;
            }
        }

        private void checkheartdb_CheckedChanged(object sender, EventArgs e)
        {
            if (checkheartdb.Checked == true)
            {
                checknoneb.Checked = false;
                chk = true;
                Disease = Disease + "  " + "Heart Diseases";
            }
            else
            {
                Disease = (Disease.Replace("Heart Diseases", ""));
                chk = false;
            }
        }

        private void checkgastrickb_CheckedChanged(object sender, EventArgs e)
        {
            if (checkgastrickb.Checked == true)
            {
                checknoneb.Checked = false;
                chk = true;
                Disease = Disease + "  " + "Gastrick";
            }
            else
            {
                Disease = (Disease.Replace("Gastrick", ""));
                chk = false;
            }
        }

        private void checkanemiab_CheckedChanged(object sender, EventArgs e)
        {
            if (checkanemiab.Checked == true)
            {
                checknoneb.Checked = false;
                chk = true;
                Disease = Disease + "  " + "Anemia";
            }
            else
            {
                Disease = (Disease.Replace("Anemia", ""));
                chk = false;
            }
        }

        private void checkallergyb_CheckedChanged(object sender, EventArgs e)
        {
            if (checkallergyb.Checked)
            {
                checknoneb.Checked = false;
                chk = true;
                Disease = Disease + "  " + "Allergy";
            }
            else
            {
                Disease = (Disease.Replace("Allergy", ""));
                chk = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
        }

        private void Pheighttxt_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}
