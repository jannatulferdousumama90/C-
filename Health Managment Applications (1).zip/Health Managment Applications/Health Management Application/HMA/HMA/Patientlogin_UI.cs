﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HMA
{
    public partial class Patientlogin_UI : Form
    {
        int Persontype;
        public Patientlogin_UI()
        {
            //  Persontype = p.PersonType;
            InitializeComponent();
            Password.PasswordChar = 'x';
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            //this.Close();
            string pass = Password.Text;
            string user = UserName.Text;
            if (Password.Text == " " || UserName.Text == "")
            {
                MessageBox.Show("Provide User name and Password");
            }
            else
            {

               // if (Persontype == 3)
                //{
                    PatientOperations op = new PatientOperations();
                    Patient P = op.GetPatient(user, pass);

                    if (P == null)
                    {
                       
                        MessageBox.Show("Credentials Incorrect");
                    }
                    else
                    {
                        MessageBox.Show("Credentials Incorrect");
                        MessageBox.Show("Login Successful !, " + P.FirstName);
                        new PatientProfile().Show();
                        this.Close();
                    }
               // }
                //else
                //{
                  //  MessageBox.Show("Credentials Incorrect");
                //}

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
             this.Close();
        }
    }

       // private void button2_Click(object sender, EventArgs e)
       // {
          //  new LoginorSignup().Show();
           // this.Close();
       // }

    
    }


