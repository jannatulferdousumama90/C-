﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class PatientsMedicalHistory_Ul : Form
    {

        Patient P;
        public PatientsMedicalHistory_Ul()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new PatientProfile().Show();
            this.Hide();
        }

        private void SeeAptpicbox_Click(object sender, EventArgs e)
        {
            new BookAppointmentUI().Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            new ViewAppointments_UI().Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            new CovidPredict_UI().Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Hide();
        }
        void populateData()
        {
            
            PrescriptionOperations OP = new PrescriptionOperations();
            DataSet ds = OP.ShowPrescription();
            HistoryDGV.DataSource = ds.Tables[0];


        }


        private void PatientsMedicalHistory_Ul_Load(object sender, EventArgs e)
        {
            populateData();
            HistoryDGV.AllowUserToAddRows = false;
            this.HistoryDGV.Columns["Prescid"].Visible = false;
            this.HistoryDGV.Columns["Pid"].Visible = false;
            this.HistoryDGV.Columns["Drid"].Visible = false;

            HistoryDGV.Columns["PatientName"].HeaderText = "Patient Name";
            HistoryDGV.Columns["DoctorName"].HeaderText = "Doctor Name";
            HistoryDGV.Columns["Treatment"].HeaderText = "Treatment";
            HistoryDGV.Columns["PrescDate"].HeaderText = "Date";
        }

        private void HistoryDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
