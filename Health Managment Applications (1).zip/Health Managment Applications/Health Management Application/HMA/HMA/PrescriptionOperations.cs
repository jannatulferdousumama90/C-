﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HMA
{
    public class PrescriptionOperations
    {
        DBConnection db = new DBConnection();
        public void InsertPrescription(Doctor Dr, Patient P)
        {
            string Query = "insert into PrescriptionTbl1  values('" + P.id + "','" + Dr.id + "','" + P.FirstName + " " + P.LastName + "','" + Dr.FirstName + " " + Dr.LastName + "','" + P.Prescription + "',GetDate())";
            try
            {
                SqlConnection con = new SqlConnection(db.connect);
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //public DataSet ShowPrescription(int key)
       // {
            //string Query = "select * from PrescriptionTbl where  Pid=" + key + "";
            //SqlConnection con = new SqlConnection(db.connect);
            //con.Open();
            //SqlCommand cmd = new SqlCommand(Query, con);
            //SqlDataAdapter sda = new SqlDataAdapter(cmd);
            //DataSet ds = new DataSet();
           // sda.Fill(ds);
           // return ds;
       // }



        public DataSet ShowPrescription()
        {
            string Query = "select * from PrescriptionTbl1";// where  Pid=" + key + "";
            SqlConnection con = new SqlConnection(db.connect);
            con.Open();
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }
    }
}
