﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class PreviousRecordUI : Form
    {

        Patient P;
        public PreviousRecordUI()
        {
            InitializeComponent();
        }

        void populateData()
        {
            PrescriptionOperations OP = new PrescriptionOperations();
            if (P == null)
            {
                MessageBox.Show("Select the Patient");
            }
            else
            {
                DataSet ds = OP.ShowPrescription();
                PrevRecordDGV.DataSource = ds.Tables[0];
            }


        }



        private void PreviousRecordUI_Load(object sender, EventArgs e)
        {
            populateData();
            PrevRecordDGV.AllowUserToAddRows = false;
            this.PrevRecordDGV.Columns["Prescid"].Visible = false;
            this.PrevRecordDGV.Columns["Pid"].Visible = false;
            this.PrevRecordDGV.Columns["Drid"].Visible = false;

            PrevRecordDGV.Columns["PatientName"].HeaderText = "Patient Name";
            PrevRecordDGV.Columns["DoctorName"].HeaderText = "Doctor Name";
            PrevRecordDGV.Columns["Treatment"].HeaderText = "Treatment";
            PrevRecordDGV.Columns["PrescDate"].HeaderText = "Date";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void PrevRecordDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
