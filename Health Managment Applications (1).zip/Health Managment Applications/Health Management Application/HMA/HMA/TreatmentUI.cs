﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class TreatmentUI : Form
    {
        Doctor Dr;
        Patient P;
        public TreatmentUI()
        {
            InitializeComponent();
        }

        void populateData()
        {
            AppointmentOperations OP = new AppointmentOperations();
            DataSet ds = OP.ShowDtAptList();
            TreatDGV.DataSource = ds.Tables[0];

        }




        private void TreatDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.TreatDGV.Rows[e.RowIndex];
                string UserName = Convert.ToString(row.Cells["UserName"].Value.ToString());
                populatePatientData(UserName);

            }

        }



        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new ViewAppointmentlist_UI().Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Hide();
        }

        private void TreatmentUI_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (P == null)
            {
                MessageBox.Show("Select the patient");
            }
            else
            {
                new PreviousRecordUI().Show();
            }
        }

       

        private void populatePatientData(string userName)
        {
            throw new NotImplementedException();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(PatientName.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Age.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Gender.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Height.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Weight.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(BloodGroup.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(Diseases.Text))
            {
                MessageBox.Show("All the information must be filled up!");
            }
            else if (String.IsNullOrEmpty(GiveTreatment.Text))
            {
                MessageBox.Show("Provide the Prescriptoin !");
            }

            else
            {
                P.Prescription = GiveTreatment.Text;
                try
                {
                    PrescriptionOperations op = new PrescriptionOperations();
                    op.InsertPrescription(Dr, P);
                    MessageBox.Show("Prescription Given !");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }



            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            new DoctorProfile().Show();
            this.Close();
        }

        private void TreatDGV_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.TreatDGV.Rows[e.RowIndex];
                string UserName = Convert.ToString(row.Cells["UserName"].Value.ToString());
                populatePatientData(UserName);

            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}


