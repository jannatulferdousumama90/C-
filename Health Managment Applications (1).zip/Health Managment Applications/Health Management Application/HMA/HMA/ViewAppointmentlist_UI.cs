﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class ViewAppointmentlist_UI : Form
    {
        
        
        Doctor Dr;

        

        public ViewAppointmentlist_UI()
        {
            
            InitializeComponent();
        }
        void populateData()
        {
            AppointmentOperations OP = new AppointmentOperations();
            DataSet ds = OP.ShowDrAptList();
            DrAptList.DataSource = ds.Tables[0];

        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

       

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            new DoctorProfile().Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new TreatmentUI().Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Hide();
        }

        private void ViewAppointment_UI_Load(object sender, EventArgs e)
        {
            populateData();
            DrAptList.CellBorderStyle = DataGridViewCellBorderStyle.None;
            DrAptList.AllowUserToAddRows = false;
            this.DrAptList.Columns["Aid"].Visible = false;
            this.DrAptList.Columns["Pid"].Visible = false;
            this.DrAptList.Columns["Drid"].Visible = false;


            DrAptList.Columns["Name"].HeaderText = "Name";
            DrAptList.Columns["UserName"].HeaderText = "User Name";
            DrAptList.Columns["Doctorname"].HeaderText = "Doctor Name";
            DrAptList.Columns["AppDAte"].HeaderText = "Appointment Date";


        }
        int key = 0;
       

       

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bip = new Bitmap(this.DrAptList.Width, this.DrAptList.Height);
            DrAptList.DrawToBitmap(bip, new Rectangle(0, 0, this.DrAptList.Width, this.DrAptList.Height));
            e.Graphics.DrawImage(bip, 100, 50);
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void printBtn_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            AppointmentOperations OP = new AppointmentOperations();
            if (key == 0)
            {
                MessageBox.Show("Select the Appointmnet");
            }
            else
            {
                try
                {

                    OP.DeleteApt(key);
                    MessageBox.Show("Appointmnet Succesfully Deleted");
                    dltlb.Text = null;
                    populateData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void DrAptList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.DrAptList.Rows[e.RowIndex];
               dltlb.Text = row.Cells["DoctorName"].Value.ToString();
            }

           if (dltlb.Text == "")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(DrAptList.SelectedRows[0].Cells[0].Value.ToString());
            }
        }
    }
}
