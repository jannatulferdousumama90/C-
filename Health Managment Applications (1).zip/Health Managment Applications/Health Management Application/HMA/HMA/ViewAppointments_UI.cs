﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMA
{
    public partial class ViewAppointments_UI : Form
    {

        Patient P;
        public ViewAppointments_UI()
        {
            InitializeComponent();
        }

        private void SeeAptpicbox_Click(object sender, EventArgs e)
        {
            new BookAppointmentUI().Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            new PatientsMedicalHistory_Ul().Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            new CovidPredict_UI().Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            new PatientProfile().Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new LoginorSignup().Show();
            this.Hide();
        }

        int key = 0;
        private void UpAptDgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.UpAptDgv.Rows[e.RowIndex];
                dltlb.Text = row.Cells["DoctorName"].Value.ToString();
            }

           if (dltlb.Text == "")
           {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(UpAptDgv.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        void populateData()
        {
            AppointmentOperations OP = new AppointmentOperations();
            DataSet ds1 = OP.ShowUpComingApt();
            DataSet ds2 = OP.ShowPrevApt();
            UpAptDgv.DataSource = ds1.Tables[0];
            PrevAptDgv.DataSource = ds2.Tables[0];
        }

        private void ViewAppointments_UI_Load(object sender, EventArgs e)
        {
            populateData();

            UpAptDgv.AllowUserToAddRows = false;
            PrevAptDgv.AllowUserToAddRows = false;
            this.UpAptDgv.Columns["Aid"].Visible = false;
            this.UpAptDgv.Columns["Pid"].Visible = false;
            this.UpAptDgv.Columns["Drid"].Visible = false;
            this.PrevAptDgv.Columns["Aid"].Visible = false;
            this.PrevAptDgv.Columns["Pid"].Visible = false;
            this.PrevAptDgv.Columns["Drid"].Visible = false;

            UpAptDgv.Columns["Name"].HeaderText = "Name";
            UpAptDgv.Columns["UserName"].HeaderText = "User Name";
            UpAptDgv.Columns["Doctorname"].HeaderText = "Doctor Name";
            UpAptDgv.Columns["AppDAte"].HeaderText = "Appointment Date";

            PrevAptDgv.Columns["Name"].HeaderText = "Name";
            PrevAptDgv.Columns["UserName"].HeaderText = "User Name";
            PrevAptDgv.Columns["Doctorname"].HeaderText = "Doctor Name";
            PrevAptDgv.Columns["AppDAte"].HeaderText = "Appointment Date";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AppointmentOperations OP = new AppointmentOperations();
            if (key == 0)
            {
                MessageBox.Show("Select the Appointmnet");
            }
            else
            {
                try
                {

                    OP.DeleteApt(key);
                    MessageBox.Show("Appointmnet Succesfully Deleted");
                   dltlb.Text = null;
                    populateData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void PrevAptDgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
